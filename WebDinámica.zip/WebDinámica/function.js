console.log("Hola");


productos = [
    {
        "id": 1,
        "titulo": "Esfera",
        "imagen": "img/esfera.png",
        "precio": 5000
    },
    {
        "id": 2,
        "titulo":"Teclado",
        "imagen" : "img/teclado.svg",
        "precio": 1500
    }
]


const section = document.getElementById("productos"); //<section> del index HTML
console.log(section);

const contenedorCards = document.createElement("div");//Creación del contendedor
contenedorCards.className = "contenedor-cards"
section.appendChild(contenedorCards); //Creación de elementos hijos


for (const i of productos) {
    const card = document.createElement("div");
    card.className = "card";//Nombre de clase del div
    contenedorCards.appendChild(card);


    const tituloProducto = document.createElement("h3");
    tituloProducto.textContent = i.titulo;
    card.appendChild(tituloProducto);

    const imagenProducto = document.createElement("img");
    imagenProducto.src = i.imagen;
    imagenProducto.className = "imagen-producto";
    card.appendChild(imagenProducto);


    const precioProducto = document.createElement("p");
    precioProducto.className = "precio-producto";
    precioProducto.textContent = "$" + i.precio;
    card.appendChild(precioProducto);

    const contenedorBoton = document.createElement("div");
    contenedorBoton.className = "contenedorBoton";
    card.appendChild(contenedorBoton);

    const botonAgregarCarro = document.createElement("button");
    botonAgregarCarro.textContent = "agregar al carrito";
    botonAgregarCarro.className = "btn btn-primary";
    botonAgregarCarro.addEventListener("click", function(){
        guardar(i);
    })
    contenedorBoton.appendChild(botonAgregarCarro);

}

const LLAVE = "carrito"

function guardar(producto){
    
    var storageActual = localStorage.getItem(LLAVE);

    var lista = [];

    if(storageActual != null){
        var storageParse = JSON.parse(storageActual);

        //lista.push(producto);
        //storageParse.push(lista);

        storageParse.push(producto);

        storageParse.push(lista);

        localStorage.setItem(LLAVE,JSON.stringify(storageParse));

    }else{
        lista.push(producto);
        localStorage.setItem(LLAVE, JSON.stringify(lista));
    }
    
}