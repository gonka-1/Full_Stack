const API_URL_PRESTAMOS = '/api/v1/prestamos';

const formAgregarPrestamo = document.getElementById('formAgregarPrestamo');
const formBuscarPrestamo = document.getElementById('formBuscarPrestamo');
const formActualizarPrestamo = document.getElementById('formActualizarPrestamo');
const formEliminarPrestamo = document.getElementById('formEliminarPrestamo');
const btnListarPrestamos = document.getElementById('btnListarPrestamos');

const mensajeAgregar = document.getElementById('mensajeAgregar');
const mensajeActualizar = document.getElementById('mensajeActualizar');
const mensajeEliminar = document.getElementById('mensajeEliminar');
const resultadoBusqueda = document.getElementById('resultadoBusqueda');
const tablaBodyPrestamos = document.querySelector('#tablaPrestamos tbody');

formAgregarPrestamo.addEventListener('submit', agregarPrestamo);
formBuscarPrestamo.addEventListener('submit', buscarPrestamoPorId);
formActualizarPrestamo.addEventListener('submit', actualizarPrestamo);
formEliminarPrestamo.addEventListener('submit', eliminarPrestamo);
btnListarPrestamos.addEventListener('click', listarPrestamos);

async function agregarPrestamo(event) {
    event.preventDefault();

    const prestamo = {
        idLibro: parseInt(document.getElementById('idLibro').value),
        runSolicitante: document.getElementById('runSolicitante').value,
        fechaSolicitud: document.getElementById('fechaSolicitud').value,
        fechaEntrega: document.getElementById('fechaEntrega').value || null,
        cantidadDias: parseInt(document.getElementById('cantidadDias').value),
        multas: parseInt(document.getElementById('multas').value),
        tituloLibro: ""
    };

    try {
        const response = await fetch(API_URL_PRESTAMOS, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prestamo)
        });

        if (!response.ok) {
            mensajeAgregar.className = 'message error';
            mensajeAgregar.textContent = 'No se pudo guardar el préstamo.';
            return;
        }

        const data = await response.json();
        mensajeAgregar.className = 'message success';
        mensajeAgregar.textContent = `Préstamo guardado correctamente. Libro asociado: ${data.tituloLibro}`;
        formAgregarPrestamo.reset();
        listarPrestamos();
    } catch (error) {
        mensajeAgregar.className = 'message error';
        mensajeAgregar.textContent = 'Error al guardar el préstamo.';
    }
}

async function buscarPrestamoPorId(event) {
    event.preventDefault();

    const id = document.getElementById('buscarIdPrestamo').value;

    try {
        const response = await fetch(`${API_URL_PRESTAMOS}/${id}`);

        if (!response.ok) {
            resultadoBusqueda.className = 'result-box error';
            resultadoBusqueda.innerHTML = 'Préstamo no encontrado.';
            return;
        }

        const prestamo = await response.json();
        resultadoBusqueda.className = 'result-box success';
        resultadoBusqueda.innerHTML = `
            <strong>ID Préstamo:</strong> ${prestamo.idPrestamo}<br>
            <strong>ID Libro:</strong> ${prestamo.idLibro}<br>
            <strong>Título Libro:</strong> ${prestamo.tituloLibro}<br>
            <strong>RUN:</strong> ${prestamo.runSolicitante}<br>
            <strong>Fecha Solicitud:</strong> ${prestamo.fechaSolicitud}<br>
            <strong>Fecha Entrega:</strong> ${prestamo.fechaEntrega}<br>
            <strong>Cantidad Días:</strong> ${prestamo.cantidadDias}<br>
            <strong>Multas:</strong> ${prestamo.multas}
        `;
    } catch (error) {
        resultadoBusqueda.className = 'result-box error';
        resultadoBusqueda.innerHTML = 'Error al buscar el préstamo.';
    }
}

async function actualizarPrestamo(event) {
    event.preventDefault();

    const id = document.getElementById('actualizarIdPrestamo').value;

    const prestamo = {
        idLibro: parseInt(document.getElementById('actualizarIdLibro').value),
        runSolicitante: document.getElementById('actualizarRunSolicitante').value,
        fechaSolicitud: document.getElementById('actualizarFechaSolicitud').value,
        fechaEntrega: document.getElementById('actualizarFechaEntrega').value || null,
        cantidadDias: parseInt(document.getElementById('actualizarCantidadDias').value),
        multas: parseInt(document.getElementById('actualizarMultas').value),
        tituloLibro: ""
    };

    try {
        const response = await fetch(`${API_URL_PRESTAMOS}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prestamo)
        });

        if (!response.ok) {
            mensajeActualizar.className = 'message error';
            mensajeActualizar.textContent = 'No se pudo actualizar el préstamo.';
            return;
        }

        const data = await response.json();
        mensajeActualizar.className = 'message success';
        mensajeActualizar.textContent = `Préstamo actualizado correctamente. Libro asociado: ${data.tituloLibro}`;
        formActualizarPrestamo.reset();
        listarPrestamos();
    } catch (error) {
        mensajeActualizar.className = 'message error';
        mensajeActualizar.textContent = 'Error al actualizar el préstamo.';
    }
}

async function eliminarPrestamo(event) {
    event.preventDefault();

    const id = document.getElementById('eliminarIdPrestamo').value;

    try {
        const response = await fetch(`${API_URL_PRESTAMOS}/${id}`, {
            method: 'DELETE'
        });

        if (!response.ok) {
            mensajeEliminar.className = 'message error';
            mensajeEliminar.textContent = 'No se pudo eliminar el préstamo.';
            return;
        }

        mensajeEliminar.className = 'message success';
        mensajeEliminar.textContent = `Préstamo con ID ${id} eliminado correctamente.`;
        formEliminarPrestamo.reset();
        listarPrestamos();
    } catch (error) {
        mensajeEliminar.className = 'message error';
        mensajeEliminar.textContent = 'Error al eliminar el préstamo.';
    }
}

async function listarPrestamos() {
    try {
        const response = await fetch(API_URL_PRESTAMOS);
        const prestamos = await response.json();

        if (!Array.isArray(prestamos) || prestamos.length === 0) {
            tablaBodyPrestamos.innerHTML = `
                <tr>
                    <td colspan="8">No hay préstamos registrados.</td>
                </tr>
            `;
            return;
        }

        tablaBodyPrestamos.innerHTML = prestamos.map(prestamo => `
            <tr>
                <td>${prestamo.idPrestamo}</td>
                <td>${prestamo.idLibro}</td>
                <td>${prestamo.tituloLibro}</td>
                <td>${prestamo.runSolicitante}</td>
                <td>${prestamo.fechaSolicitud}</td>
                <td>${prestamo.fechaEntrega ?? ''}</td>
                <td>${prestamo.cantidadDias}</td>
                <td>${prestamo.multas}</td>
            </tr>
        `).join('');
    } catch (error) {
        tablaBodyPrestamos.innerHTML = `
            <tr>
                <td colspan="8">Error al cargar los préstamos.</td>
            </tr>
        `;
    }
}
