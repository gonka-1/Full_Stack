const API_URL = '/api/v1/libros';
const API_URL_TODOS = '/api/v1/libros/todos';

const tablaBody = document.querySelector('#tablaLibros tbody');
const btnListar = document.getElementById('btnListar');
const formAgregar = document.getElementById('formAgregar');
const formBuscar = document.getElementById('formBuscar');
const formEliminar = document.getElementById('formEliminar');
const mensajeAgregar = document.getElementById('mensajeAgregar');
const resultadoBusqueda = document.getElementById('resultadoBusqueda');
const mensajeEliminar = document.getElementById('mensajeEliminar');

btnListar.addEventListener('click', listarLibros);
formAgregar.addEventListener('submit', agregarLibro);
formBuscar.addEventListener('submit', buscarLibroPorId);
formEliminar.addEventListener('submit', eliminarLibro);

async function listarLibros() {
    try {
        const response = await fetch(API_URL_TODOS);
        const libros = await response.json();

        if (!Array.isArray(libros) || libros.length === 0) {
            tablaBody.innerHTML = `
                <tr>
                    <td colspan="6" class="empty">No hay libros registrados.</td>
                </tr>
            `;
            return;
        }

        tablaBody.innerHTML = libros.map(libro => `
            <tr>
                <td>${libro.id}</td>
                <td>${libro.isbn}</td>
                <td>${libro.titulo}</td>
                <td>${libro.editorial}</td>
                <td>${libro.fechaPublicacion}</td>
                <td>${libro.autor}</td>
            </tr>
        `).join('');
    } catch (error) {
        tablaBody.innerHTML = `
            <tr>
                <td colspan="6" class="empty">Error al cargar los libros.</td>
            </tr>
        `;
    }
}

async function agregarLibro(event) {
    event.preventDefault();

    const libro = {
        id: parseInt(document.getElementById('id').value),
        isbn: document.getElementById('isbn').value,
        titulo: document.getElementById('titulo').value,
        editorial: document.getElementById('editorial').value,
        fechaPublicacion: parseInt(document.getElementById('fechaPublicacion').value),
        autor: document.getElementById('autor').value
    };

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(libro)
        });

        const contentType = response.headers.get('content-type') || '';
        let mensaje = '';

        if (contentType.includes('application/json')) {
            const data = await response.json();
            mensaje = `Libro ingresado correctamente: ${data.titulo || libro.titulo}`;
        } else {
            mensaje = await response.text();
        }

        mensajeAgregar.className = 'message success';
        mensajeAgregar.textContent = mensaje || `Libro ingresado correctamente: ${libro.titulo}`;
        formAgregar.reset();
        listarLibros();
    } catch (error) {
        mensajeAgregar.className = 'message error';
        mensajeAgregar.textContent = 'Ocurrió un error al agregar el libro.';
    }
}

async function buscarLibroPorId(event) {
    event.preventDefault();
    const id = document.getElementById('buscarId').value;

    try {
        const response = await fetch(`${API_URL}/${id}`);
        const contentType = response.headers.get('content-type') || '';

        if (!response.ok) {
            throw new Error('No se pudo consultar el libro.');
        }

        if (contentType.includes('application/json')) {
            const libro = await response.json();

            if (!libro) {
                throw new Error('Libro no encontrado.');
            }

            resultadoBusqueda.className = 'result-box success';
            resultadoBusqueda.innerHTML = `
                <strong>Libro encontrado</strong><br>
                ID: ${libro.id}<br>
                ISBN: ${libro.isbn}<br>
                Título: ${libro.titulo}<br>
                Editorial: ${libro.editorial}<br>
                Año: ${libro.fechaPublicacion}<br>
                Autor: ${libro.autor}
            `;
        } else {
            const texto = await response.text();
            resultadoBusqueda.className = 'result-box';
            resultadoBusqueda.textContent = texto;
        }
    } catch (error) {
        resultadoBusqueda.className = 'result-box error';
        resultadoBusqueda.textContent = 'No se encontró un libro con ese ID.';
    }
}

async function eliminarLibro(event) {
    event.preventDefault();
    const id = document.getElementById('eliminarId').value;

    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE'
        });

        const texto = await response.text();
        mensajeEliminar.className = 'message success';
        mensajeEliminar.textContent = texto || `Libro con ID ${id} eliminado correctamente.`;
        formEliminar.reset();
        listarLibros();
    } catch (error) {
        mensajeEliminar.className = 'message error';
        mensajeEliminar.textContent = 'Ocurrió un error al eliminar el libro.';
    }
}

listarLibros();
