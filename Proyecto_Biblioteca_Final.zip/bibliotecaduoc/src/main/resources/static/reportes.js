const API_REPORTES = '/api/v1/libros';

const formIsbn = document.getElementById('formIsbn');
const formAnioCantidad = document.getElementById('formAnioCantidad');
const formAutor = document.getElementById('formAutor');
const btnMasAntiguo = document.getElementById('btnMasAntiguo');
const btnMasNuevo = document.getElementById('btnMasNuevo');
const btnOrdenados = document.getElementById('btnOrdenados');

const resultadoIsbn = document.getElementById('resultadoIsbn');
const resultadoCantidad = document.getElementById('resultadoCantidad');
const resultadoAutor = document.getElementById('resultadoAutor');
const resultadoAntiguo = document.getElementById('resultadoAntiguo');
const resultadoNuevo = document.getElementById('resultadoNuevo');
const tablaOrdenadosBody = document.querySelector('#tablaOrdenados tbody');

formIsbn.addEventListener('submit', buscarPorIsbn);
formAnioCantidad.addEventListener('submit', buscarCantidadPorAnio);
formAutor.addEventListener('submit', buscarPorAutor);
btnMasAntiguo.addEventListener('click', buscarMasAntiguo);
btnMasNuevo.addEventListener('click', buscarMasNuevo);
btnOrdenados.addEventListener('click', listarOrdenadosPorAnio);

function construirFichaLibro(libro, titulo) {
    if (!libro) {
        return 'No se encontró información para mostrar.';
    }

    return `
        <strong>${titulo}</strong><br>
        ID: ${libro.id}<br>
        ISBN: ${libro.isbn}<br>
        Título: ${libro.titulo}<br>
        Editorial: ${libro.editorial}<br>
        Año: ${libro.fechaPublicacion}<br>
        Autor: ${libro.autor}
    `;
}

async function buscarPorIsbn(event) {
    event.preventDefault();
    const isbn = document.getElementById('isbnBuscar').value;

    try {
        const response = await fetch(`${API_REPORTES}/isbn?isbn=${encodeURIComponent(isbn)}`);
        const libro = await response.json();

        if (!libro) {
            throw new Error('Libro no encontrado');
        }

        resultadoIsbn.className = 'result-box success';
        resultadoIsbn.innerHTML = construirFichaLibro(libro, 'Libro encontrado por ISBN');
    } catch (error) {
        resultadoIsbn.className = 'result-box error';
        resultadoIsbn.textContent = 'No se encontró un libro con ese ISBN.';
    }
}

async function buscarCantidadPorAnio(event) {
    event.preventDefault();
    const anio = document.getElementById('anioCantidad').value;

    try {
        const response = await fetch(`${API_REPORTES}/anio/${anio}/cantidad`);
        const cantidad = await response.text();

        resultadoCantidad.className = 'result-box success';
        resultadoCantidad.innerHTML = `<strong>Resultado</strong><br>En el año ${anio} se publicaron ${cantidad} libro(s).`;
    } catch (error) {
        resultadoCantidad.className = 'result-box error';
        resultadoCantidad.textContent = 'Ocurrió un error al consultar la cantidad de libros por año.';
    }
}

async function buscarPorAutor(event) {
    event.preventDefault();
    const autor = document.getElementById('autorBuscar').value;

    try {
        const response = await fetch(`${API_REPORTES}/autor?autor=${encodeURIComponent(autor)}`);
        const libros = await response.json();

        if (!Array.isArray(libros) || libros.length === 0) {
            throw new Error('Autor sin resultados');
        }

        resultadoAutor.className = 'result-box success';
        resultadoAutor.innerHTML = `
            <strong>Libros encontrados para el autor: ${autor}</strong><br><br>
            ${libros.map(libro => `
                ID: ${libro.id} - ${libro.titulo} (${libro.fechaPublicacion})<br>
                ISBN: ${libro.isbn}<br>
                Editorial: ${libro.editorial}<br><br>
            `).join('')}
        `;
    } catch (error) {
        resultadoAutor.className = 'result-box error';
        resultadoAutor.textContent = 'No se encontraron libros para ese autor.';
    }
}

async function buscarMasAntiguo() {
    try {
        const response = await fetch(`${API_REPORTES}/mas-antiguo`);
        const libro = await response.json();

        resultadoAntiguo.className = 'result-box success';
        resultadoAntiguo.innerHTML = construirFichaLibro(libro, 'Libro más antiguo');
    } catch (error) {
        resultadoAntiguo.className = 'result-box error';
        resultadoAntiguo.textContent = 'Ocurrió un error al buscar el libro más antiguo.';
    }
}

async function buscarMasNuevo() {
    try {
        const response = await fetch(`${API_REPORTES}/mas-nuevo`);
        const libro = await response.json();

        resultadoNuevo.className = 'result-box success';
        resultadoNuevo.innerHTML = construirFichaLibro(libro, 'Libro más nuevo');
    } catch (error) {
        resultadoNuevo.className = 'result-box error';
        resultadoNuevo.textContent = 'Ocurrió un error al buscar el libro más nuevo.';
    }
}

async function listarOrdenadosPorAnio() {
    try {
        const response = await fetch(`${API_REPORTES}/ordenados/anio`);
        const libros = await response.json();

        if (!Array.isArray(libros) || libros.length === 0) {
            tablaOrdenadosBody.innerHTML = `
                <tr>
                    <td colspan="6" class="empty">No hay libros para mostrar.</td>
                </tr>
            `;
            return;
        }

        tablaOrdenadosBody.innerHTML = libros.map(libro => `
            <tr>
                <td>${libro.id}</td>
                <td>${libro.isbn}</td>
                <td>${libro.titulo}</td>
                <td>${libro.editorial}</td>
                <td>${libro.fechaPublicacion}</td>
                <td>${libro.autor}</td>
            </tr>
        `).join('');
    } catch (error) {
        tablaOrdenadosBody.innerHTML = `
            <tr>
                <td colspan="6" class="empty">Error al cargar los libros ordenados.</td>
            </tr>
        `;
    }
}
