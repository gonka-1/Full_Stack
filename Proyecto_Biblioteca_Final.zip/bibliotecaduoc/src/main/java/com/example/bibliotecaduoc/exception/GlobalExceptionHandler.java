package com.example.bibliotecaduoc.exception; // Paquete donde se encuentra el manejador global de errores

import org.springframework.http.HttpStatus; // Permite usar códigos HTTP
import org.springframework.http.ResponseEntity; // Permite devolver respuestas HTTP completas
import org.springframework.validation.FieldError; // Permite acceder a los errores de validación por campo
import org.springframework.web.bind.MethodArgumentNotValidException; // Excepción que Spring lanza cuando falla @Valid
import org.springframework.web.bind.annotation.ExceptionHandler; // Permite capturar excepciones específicas
import org.springframework.web.bind.annotation.RestControllerAdvice; // Marca esta clase como manejador global de errores

import java.util.LinkedHashMap; // Permite crear un mapa ordenado
import java.util.Map; // Importa la interfaz Map

@RestControllerAdvice // Indica que esta clase manejará errores de todos los controllers
public class GlobalExceptionHandler { // Inicio de la clase GlobalExceptionHandler

    @ExceptionHandler(MethodArgumentNotValidException.class) // Captura errores de validación de @Valid
    public ResponseEntity<Map<String, String>> manejarErroresDeValidacion(MethodArgumentNotValidException ex) { // Método para manejar errores de validación
        Map<String, String> errores = new LinkedHashMap<>(); // Crea un mapa para guardar campo y mensaje de error

        for (FieldError error : ex.getBindingResult().getFieldErrors()) { // Recorre todos los errores encontrados
            errores.put(error.getField(), error.getDefaultMessage()); // Guarda el nombre del campo y su mensaje
        } // Fin FOR errores de validación

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errores); // Retorna 400 con el detalle de los errores
    } // Fin método manejarErroresDeValidacion

    @ExceptionHandler(LibroNoEncontradoException.class) // Captura errores de libro no encontrado
    public ResponseEntity<String> manejarLibroNoEncontrado(LibroNoEncontradoException ex) { // Método para manejar libro no encontrado
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage()); // Retorna 404 con el mensaje del error
    } // Fin método manejarLibroNoEncontrado

    @ExceptionHandler(PrestamoNoEncontradoException.class) // Captura errores de préstamo no encontrado
    public ResponseEntity<String> manejarPrestamoNoEncontrado(PrestamoNoEncontradoException ex) { // Método para manejar préstamo no encontrado
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage()); // Retorna 404 con el mensaje del error
    } // Fin método manejarPrestamoNoEncontrado

    @ExceptionHandler(IsbnDuplicadoException.class) // Captura errores de ISBN duplicado
    public ResponseEntity<String> manejarIsbnDuplicado(IsbnDuplicadoException ex) { // Método para manejar ISBN duplicado
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage()); // Retorna 400 con el mensaje del error
    } // Fin método manejarIsbnDuplicado

    @ExceptionHandler(LibroAsociadoNoEncontradoException.class) // Captura errores de libro asociado no encontrado
    public ResponseEntity<String> manejarLibroAsociadoNoEncontrado(LibroAsociadoNoEncontradoException ex) { // Método para manejar libro asociado no encontrado
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage()); // Retorna 400 con el mensaje del error
    } // Fin método manejarLibroAsociadoNoEncontrado

    @ExceptionHandler(Exception.class) // Captura cualquier error inesperado
    public ResponseEntity<String> manejarErrorGeneral(Exception ex) { // Método para manejar errores generales
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error interno del servidor."); // Retorna 500 con mensaje general
    } // Fin método manejarErrorGeneral

} // Fin de la clase GlobalExceptionHandler