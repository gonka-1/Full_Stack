package com.example.bibliotecaduoc.exception; // Paquete donde se encuentra la excepción

public class LibroNoEncontradoException extends RuntimeException { // Inicio clase LibroNoEncontradoException

    public LibroNoEncontradoException(String mensaje) { // Constructor que recibe el mensaje de error
        super(mensaje); // Envía el mensaje a la clase padre RuntimeException
    } // Fin constructor

} // Fin clase LibroNoEncontradoException