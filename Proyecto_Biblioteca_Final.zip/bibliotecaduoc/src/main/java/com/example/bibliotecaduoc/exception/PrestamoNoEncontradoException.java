package com.example.bibliotecaduoc.exception; // Paquete donde se encuentra la excepción

public class PrestamoNoEncontradoException extends RuntimeException { // Inicio clase PrestamoNoEncontradoException

    public PrestamoNoEncontradoException(String mensaje) { // Constructor que recibe el mensaje de error
        super(mensaje); // Envía el mensaje a la clase padre RuntimeException
    } // Fin constructor

} // Fin clase PrestamoNoEncontradoExceptio