package com.example.bibliotecaduoc.repository; // Paquete donde se encuentra el repository

import com.example.bibliotecaduoc.model.Prestamo; // Importa la clase Prestamo
import org.springframework.stereotype.Repository; // Marca esta clase como repository

import java.util.ArrayList; // Importa ArrayList
import java.util.List; // Importa List

@Repository // Indica que esta clase pertenece a la capa repository
public class PrestamoRepository { // Inicio clase PrestamoRepository

    private List<Prestamo> listaPrestamos = new ArrayList<>(); // Lista que guarda todos los préstamos
    private int ultimoId = 0; // Variable para generar ids automáticos

    public Prestamo guardar(Prestamo prestamo) { // Método para guardar un nuevo préstamo
        ultimoId++; // Aumenta el valor del último id
        prestamo.setIdPrestamo(ultimoId); // Asigna el nuevo id al préstamo
        listaPrestamos.add(prestamo); // Agrega el préstamo a la lista
        return prestamo; // Retorna el préstamo guardado
    } // fin método guardar


    //--------------PARTE 2 BUSQUEDA DE PRESTAMO POR ID

    public Prestamo buscarPorId(int id) { // Método para buscar un préstamo por su id
        for (Prestamo prestamo : listaPrestamos) { // Recorre cada préstamo de la lista
            if (prestamo.getIdPrestamo() == id) { // Compara el id del préstamo actual con el id recibido
                return prestamo; // Retorna el préstamo encontrado
            } // fin IF búsqueda por id
        } // fin FOR búsqueda por id
        return null; // Si no encuentra el préstamo, retorna null
    } // fin método buscarPorId



    //--------------PARTE 3

    public List<Prestamo> obtenerPrestamos() { // Método para listar todos los préstamos
        return listaPrestamos; // Retorna la lista completa de préstamos
    } // fin método obtenerPrestamos

    public Prestamo actualizar(int id, Prestamo prestamoActualizado) { // Método para actualizar un préstamo
        for (int i = 0; i < listaPrestamos.size(); i++) { // Recorre la lista usando posiciones
            if (listaPrestamos.get(i).getIdPrestamo() == id) { // Compara el id del préstamo actual con el id recibido
                prestamoActualizado.setIdPrestamo(id); // Mantiene el mismo id del préstamo
                listaPrestamos.set(i, prestamoActualizado); // Reemplaza el préstamo antiguo por el nuevo
                return prestamoActualizado; // Retorna el préstamo actualizado
            } // fin IF actualización
        } // fin FOR actualización
        return null; // Si no encuentra el préstamo, retorna null
    } // fin método actualizar

    public boolean eliminar(int id) { // Método para eliminar un préstamo por id
        for (int i = 0; i < listaPrestamos.size(); i++) { // Recorre la lista usando posiciones
            if (listaPrestamos.get(i).getIdPrestamo() == id) { // Compara el id del préstamo actual con el id recibido
                listaPrestamos.remove(i); // Elimina el préstamo encontrado
                return true; // Retorna true si se eliminó correctamente
            } // fin IF eliminación
        } // fin FOR eliminación
        return false; // Si no encuentra el préstamo, retorna false
    } // fin método eliminar



} // fin clase PrestamoRepository