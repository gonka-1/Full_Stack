package com.example.bibliotecaduoc.service; // Paquete donde se encuentra el service

import com.example.bibliotecaduoc.exception.LibroAsociadoNoEncontradoException; // Importa la excepción para libro asociado inexistente
import com.example.bibliotecaduoc.exception.LibroNoEncontradoException; // Importa la excepción de libro no encontrado
import com.example.bibliotecaduoc.exception.PrestamoNoEncontradoException; // Importa la excepción para préstamo no encontrado
import com.example.bibliotecaduoc.model.Libro; // Importa la clase Libro
import com.example.bibliotecaduoc.model.Prestamo; // Importa la clase Prestamo
import com.example.bibliotecaduoc.repository.PrestamoRepository; // Importa la clase PrestamoRepository
import org.springframework.beans.factory.annotation.Autowired; // Permite inyectar dependencias
import org.springframework.stereotype.Service; // Marca esta clase como service

import java.util.List; // Importa la interfaz List

@Service // Indica que esta clase pertenece a la capa service
public class PrestamoService { // Inicio clase PrestamoService

    @Autowired // Inyecta automáticamente el repository de préstamos
    private PrestamoRepository prestamoRepository; // Variable para usar los métodos del repository

    @Autowired // Inyecta automáticamente el servicio de libros
    private LibroService libroService; // Variable para consultar libros asociados al préstamo

    public Prestamo savePrestamo(Prestamo prestamo) { // Método para guardar un préstamo
        Libro libroAsociado = obtenerLibroAsociado(prestamo.getIdLibro()); // Busca el libro asociado al préstamo

        Prestamo nuevoPrestamo = prestamoRepository.guardar(prestamo); // Guarda el préstamo en el repositorio
        nuevoPrestamo.setTituloLibro(libroAsociado.getTitulo()); // Asigna el título del libro al préstamo guardado

        return nuevoPrestamo; // Retorna el préstamo guardado
    } // Fin método savePrestamo

    public Prestamo getPrestamoPorId(int id) { // Método para buscar un préstamo por id
        Prestamo prestamo = prestamoRepository.buscarPorId(id); // Busca el préstamo en el repositorio

        if (prestamo == null) { // Verifica si el préstamo no existe
            throw new PrestamoNoEncontradoException("Préstamo con ID " + id + " no encontrado."); // Lanza error si no existe
        } // Fin IF préstamo no encontrado

        Libro libroAsociado = obtenerLibroAsociado(prestamo.getIdLibro()); // Busca el libro asociado al préstamo
        prestamo.setTituloLibro(libroAsociado.getTitulo()); // Asigna el título del libro al préstamo

        return prestamo; // Retorna el préstamo encontrado
    } // Fin método getPrestamoPorId

    public List<Prestamo> getPrestamos() { // Método para obtener todos los préstamos
        List<Prestamo> listaPrestamos = prestamoRepository.obtenerPrestamos(); // Obtiene la lista completa de préstamos

        for (Prestamo prestamo : listaPrestamos) { // Recorre cada préstamo de la lista
            Libro libroAsociado = obtenerLibroAsociado(prestamo.getIdLibro()); // Busca el libro asociado al préstamo actual
            prestamo.setTituloLibro(libroAsociado.getTitulo()); // Asigna el título del libro al préstamo actual
        } // Fin FOR lista de préstamos

        return listaPrestamos; // Retorna la lista completa ya enriquecida con título del libro
    } // Fin método getPrestamos

    public Prestamo updatePrestamo(int id, Prestamo prestamo) { // Método para actualizar un préstamo
        Prestamo prestamoActual = prestamoRepository.buscarPorId(id); // Busca el préstamo actual por su id

        if (prestamoActual == null) { // Verifica si el préstamo no existe
            throw new PrestamoNoEncontradoException("Préstamo con ID " + id + " no encontrado."); // Lanza error si no existe
        } // Fin IF préstamo no encontrado

        Libro libroAsociado = obtenerLibroAsociado(prestamo.getIdLibro()); // Busca el libro asociado al préstamo actualizado

        Prestamo prestamoActualizado = prestamoRepository.actualizar(id, prestamo); // Actualiza el préstamo en el repositorio
        prestamoActualizado.setTituloLibro(libroAsociado.getTitulo()); // Asigna el título del libro al préstamo actualizado

        return prestamoActualizado; // Retorna el préstamo actualizado
    } // Fin método updatePrestamo

    public boolean deletePrestamo(int id) { // Método para eliminar un préstamo
        boolean eliminado = prestamoRepository.eliminar(id); // Intenta eliminar el préstamo desde el repositorio

        if (!eliminado) { // Verifica si no se pudo eliminar porque no existía
            throw new PrestamoNoEncontradoException("Préstamo con ID " + id + " no encontrado."); // Lanza error si no existe
        } // Fin IF préstamo no encontrado

        return true; // Retorna true cuando el préstamo fue eliminado correctamente
    } // Fin método deletePrestamo

    private Libro obtenerLibroAsociado(int idLibro) { // Método privado para obtener el libro asociado al préstamo
        try { // Intenta buscar el libro usando el servicio de libros
            return libroService.getLibroId(idLibro); // Retorna el libro si existe
        } catch (LibroNoEncontradoException ex) { // Captura el error si el libro no existe
            throw new LibroAsociadoNoEncontradoException("El libro asociado al préstamo no existe."); // Lanza un mensaje más claro para el contexto de préstamo
        } // Fin catch libro asociado no encontrado
    } // Fin método obtenerLibroAsociado

} // Fin clase PrestamoService