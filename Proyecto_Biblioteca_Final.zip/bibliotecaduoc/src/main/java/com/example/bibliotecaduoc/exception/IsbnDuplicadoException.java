package com.example.bibliotecaduoc.exception; // Paquete donde se encuentra la excepción

public class IsbnDuplicadoException extends RuntimeException { // Inicio clase IsbnDuplicadoException

    public IsbnDuplicadoException(String mensaje) { // Constructor que recibe el mensaje de error
        super(mensaje); // Envía el mensaje a la clase padre RuntimeException
    } // Fin constructor

} // Fin clase IsbnDuplicadoException