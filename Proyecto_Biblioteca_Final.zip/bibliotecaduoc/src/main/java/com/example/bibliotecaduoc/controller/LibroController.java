package com.example.bibliotecaduoc.controller; // Paquete donde se encuentra esta clase Controller

import com.example.bibliotecaduoc.model.Libro; // Importa la clase Libro, que representa el objeto o entidad
import com.example.bibliotecaduoc.service.LibroService; // Importa la clase de servicio que contiene la lógica del negocio
import jakarta.validation.Valid; // Activa las validaciones del modelo Libro
import org.springframework.beans.factory.annotation.Autowired; // Permite inyectar dependencias automáticamente
import org.springframework.web.bind.annotation.*; // Importa las anotaciones REST de Spring
import java.util.List; // Importa la interfaz List para trabajar con listas de libros

@RestController // Indica que esta clase es un controlador REST
@RequestMapping("/api/v1/libros") // Define la ruta base para todos los endpoints de este controlador
public class LibroController { // Inicio de la clase LibroController

    @Autowired // Inyecta automáticamente un objeto de tipo LibroService
    private LibroService libroService; // Variable que permite usar los métodos del servicio

    @GetMapping("/todos") // Este método responde a peticiones GET a /api/v1/libros/todos
    public List<Libro> listarLibros() { // Método para listar todos los libros
        return libroService.getLibros(); // Llama al servicio y devuelve la lista completa de libros
    } // fin método listarLibros

    @PostMapping // Este método responde a peticiones POST a /api/v1/libros
    public String agregarLibro(@Valid @RequestBody Libro libro) { // Método para agregar un nuevo libro validado
        libroService.saveLibro(libro); // Guarda el libro usando el servicio
        return "Libro ingresado correctamente: " + libro.getTitulo(); // Devuelve un mensaje de confirmación
    } // fin método agregarLibro

    @GetMapping("{id}") // Este método responde a peticiones GET a /api/v1/libros/{id}
    public Libro buscarLibro(@PathVariable int id) { // Método para buscar un libro por su ID recibido en la URL
        return libroService.getLibroId(id); // Llama al servicio y devuelve el libro encontrado
    } // fin método buscarLibro

    @PutMapping("{id}") // Este método responde a peticiones PUT a /api/v1/libros/{id}
    public Libro actualizarLibro(@PathVariable int id, @Valid @RequestBody Libro libro) { // Método para actualizar un libro validado
        return libroService.updateLibro(libro); // Envía el libro al servicio para actualizarlo
    } // fin método actualizarLibro

    @DeleteMapping("{id}") // Este método responde a peticiones DELETE a /api/v1/libros/{id}
    public String eliminarLibro(@PathVariable int id) { // Método para eliminar un libro según su ID
        return libroService.deleteLibro(id); // Llama al servicio para eliminar el libro y devuelve un mensaje
    } // fin método eliminarLibro

    @GetMapping("/total") // Este método responde a peticiones GET a /api/v1/libros/total
    public int totalLibrosV2() { // Método para obtener el total de libros
        return libroService.totalLibrosV2(); // Llama al servicio y devuelve la cantidad total de libros
    } // fin método totalLibrosV2

    @GetMapping("/isbn") // Este método responde a peticiones GET a /api/v1/libros/isbn?isbn=...
    public Libro buscarLibroPorIsbn(@RequestParam String isbn) { // Método para buscar un libro por ISBN
        return libroService.getLibroPorIsbn(isbn); // Llama al servicio y retorna el libro encontrado
    } // fin método buscarLibroPorIsbn

    @GetMapping("/anio/{anio}/cantidad") // Este método responde a peticiones GET a /api/v1/libros/anio/{anio}/cantidad
    public int buscarCantidadLibrosPorAnio(@PathVariable int anio) { // Método para obtener la cantidad de libros publicados en un año
        return libroService.getCantidadLibrosPorAnio(anio); // Llama al servicio y retorna la cantidad encontrada
    } // fin método buscarCantidadLibrosPorAnio

    @GetMapping("/autor") // Este método responde a peticiones GET a /api/v1/libros/autor?autor=...
    public List<Libro> buscarLibrosPorAutor(@RequestParam String autor) { // Método para buscar libros por autor
        return libroService.getLibrosPorAutor(autor); // Llama al servicio y retorna la lista encontrada
    } // fin método buscarLibrosPorAutor

    @GetMapping("/mas-antiguo") // Este método responde a peticiones GET a /api/v1/libros/mas-antiguo
    public Libro buscarLibroMasAntiguo() { // Método para obtener el libro más antiguo
        return libroService.getLibroMasAntiguo(); // Llama al servicio y retorna el libro más antiguo
    } // fin método buscarLibroMasAntiguo

    @GetMapping("/mas-nuevo") // Este método responde a peticiones GET a /api/v1/libros/mas-nuevo
    public Libro buscarLibroMasNuevo() { // Método para obtener el libro más nuevo
        return libroService.getLibroMasNuevo(); // Llama al servicio y retorna el libro más nuevo
    } // fin método buscarLibroMasNuevo

    @GetMapping("/ordenados/anio") // Este método responde a peticiones GET a /api/v1/libros/ordenados/anio
    public List<Libro> listarLibrosOrdenadosPorAnio() { // Método para listar todos los libros ordenados por año
        return libroService.getLibrosOrdenadosPorAnio(); // Llama al servicio y retorna la lista ordenada
    } // fin método listarLibrosOrdenadosPorAnio

} // fin clase LibroController