package com.example.bibliotecaduoc.repository; // Paquete donde se encuentra la capa repository

import com.example.bibliotecaduoc.model.Libro; // Importa la clase Libro para manejar objetos de tipo Libro
import org.springframework.stereotype.Repository; // Permite marcar esta clase como repositorio de Spring

import java.util.ArrayList; // Importa ArrayList para crear una lista dinámica
import java.util.List; // Importa List para trabajar con colecciones de libros

@Repository // Indica que esta clase pertenece a la capa de acceso a datos
public class LibroRepository { // Inicio de la clase LibroRepository

    // Lista que guardará todos los libros en memoria mientras la aplicación esté encendida
    private List<Libro> listaLibros = new ArrayList<>(); // Se crea una lista vacía de libros

    public LibroRepository() { // Constructor del repositorio
        // Se agregan libros por defecto al iniciar la aplicación
        listaLibros.add(new Libro(1, "9789569646638", "Fuego y Sangre", "Penguin Random House Grupo Editorial", 2018, "George R. R. Martin")); // Agrega el libro 1
        listaLibros.add(new Libro(2, "9789563494150", "Quique Hache: El Mall Embrujado y Otras Historias", "Sm Ediciones", 2014, "Sergio Gomez")); // Agrega el libro 2
        listaLibros.add(new Libro(3, "9781484256251", "Spring Boot Persistence Best Practices", "Apress", 2020, "Anghel Leonard")); // Agrega el libro 3
        listaLibros.add(new Libro(4, "9789566075752", "Harry Potter y la piedra filosofal", "Salamandra", 2024, "J. K. Rowling")); // Agrega el libro 4
        listaLibros.add(new Libro(5, "9780439139601", "Harry Potter y el prisionero de Azkaban", "Scholastic", 1999, "J. K. Rowling")); // Agrega el libro 5
        listaLibros.add(new Libro(6, "9780439136365", "Harry Potter y el cáliz de fuego", "Scholastic", 2000, "J. K. Rowling")); // Agrega el libro 6
        listaLibros.add(new Libro(7, "9780321127426", "Effective Java", "Addison-Wesley", 2008, "Joshua Bloch")); // Agrega el libro 7
        listaLibros.add(new Libro(8, "9780134685991", "Clean Architecture", "Prentice Hall", 2017, "Robert C. Martin")); // Agrega el libro 8
        listaLibros.add(new Libro(9, "9780201633610", "Design Patterns", "Addison-Wesley", 1994, "Erich Gamma, Richard Helm, Ralph Johnson, John Vlissides")); // Agrega el libro 9
        listaLibros.add(new Libro(10, "9780132350884", "Clean Code", "Prentice Hall", 2008, "Robert C. Martin")); // Agrega el libro 10
    } // fin constructor LibroRepository

    // Método que devuelve todos los libros almacenados en la lista
    public List<Libro> obtenerLibros() { // Método para obtener la colección completa de libros
        return listaLibros; // Retorna la lista completa de libros
    } // fin método obtenerLibros

    // Método que busca un libro por su id
    public Libro buscarPorId(int id) { // Método para buscar un libro usando el id
        for (Libro libro : listaLibros) { // Recorre cada libro de la lista
            if (libro.getId() == id) { // Compara el id del libro actual con el id recibido
                return libro; // Retorna el libro cuando encuentra coincidencia
            } // fin IF búsqueda por id
        } // fin FOR búsqueda por id
        return null; // Si no encuentra coincidencia, retorna null
    } // fin método buscarPorId

    // Método que busca un libro por su ISBN
    public Libro buscarPorIsbn(String isbn) { // Método para buscar un libro usando el ISBN
        for (Libro libro : listaLibros) { // Recorre cada libro de la lista
            if (libro.getIsbn().equals(isbn)) { // Compara el ISBN del libro actual con el ISBN recibido
                return libro; // Retorna el libro cuando encuentra coincidencia
            } // fin IF búsqueda por ISBN
        } // fin FOR búsqueda por ISBN
        return null; // Si no encuentra coincidencia, retorna null
    } // fin método buscarPorIsbn

    public Libro guardar(Libro lib) { // Método para guardar un nuevo libro en la lista
//        Libro libro = new Libro(); // Alternativa comentada: crear un nuevo objeto libro
//        libro.setId(lib.getId()); // Alternativa comentada: asignar el id al nuevo objeto
//        libro.setIsbn(lib.getIsbn()); // Alternativa comentada: asignar el isbn al nuevo objeto
//        libro.setTitulo(lib.getTitulo()); // Alternativa comentada: asignar el título al nuevo objeto
//        libro.setAutor(lib.getAutor()); // Alternativa comentada: asignar el autor al nuevo objeto
//        libro.setFechaPublicacion(lib.getFechaPublicacion()); // Alternativa comentada: asignar la fecha de publicación
//        libro.setEditorial(lib.getEditorial()); // Alternativa comentada: asignar la editorial

        listaLibros.add(lib); // Agrega el libro recibido a la lista en memoria
        return lib; // Retorna el mismo libro que fue agregado
    } // fin método guardar

    public Libro actualizar(Libro lib) { // Método para actualizar un libro existente
        int id = 0; // Variable auxiliar para guardar el id del libro encontrado
        int idPosicion = 0; // Variable auxiliar para guardar la posición del libro dentro de la lista

        for (int i = 0; i < listaLibros.size(); i++) { // Recorre la lista usando índices
            if (listaLibros.get(i).getId() == lib.getId()) { // Compara el id del libro actual con el id del libro recibido
                id = lib.getId(); // Guarda el id del libro encontrado
                idPosicion = i; // Guarda la posición donde se encontró el libro
            } // fin IF actualización
        } // fin FOR actualización

        Libro libro1 = new Libro(); // Crea un nuevo objeto Libro que reemplazará al anterior
        libro1.setId(id); // Asigna el id al nuevo objeto
        libro1.setTitulo(lib.getTitulo()); // Asigna el título recibido al nuevo objeto
        libro1.setAutor(lib.getAutor()); // Asigna el autor recibido al nuevo objeto
        libro1.setFechaPublicacion(lib.getFechaPublicacion()); // Asigna la fecha de publicación al nuevo objeto
        libro1.setEditorial(lib.getEditorial()); // Asigna la editorial al nuevo objeto
        libro1.setIsbn(lib.getIsbn()); // Asigna el ISBN al nuevo objeto

        listaLibros.set(idPosicion, libro1); // Reemplaza en la lista el libro antiguo por el libro nuevo actualizado
        return libro1; // Retorna el libro actualizado
    } // fin método actualizar

    public void eliminar(int id) { // Método para eliminar un libro de la lista según su id
        // alternativa 1
//        Libro libro = buscarPorId(id); // Busca primero el libro por id
//        if (libro != null) { // Verifica que el libro exista
//            listaLibros.remove(libro); // Elimina el libro encontrado
//        } // fin IF alternativa 1
//
//        // alternativa 2
//        int idPosicion = 0; // Variable para guardar la posición del libro a eliminar
//        for (int i = 0; i < listaLibros.size(); i++) { // Recorre la lista usando índices
//            if (listaLibros.get(i).getId() == id) { // Compara el id de cada libro con el id recibido
//                idPosicion = i; // Guarda la posición encontrada
//                break; // Detiene el ciclo una vez encontrado el libro
//            } // fin IF alternativa 2
//        } // fin FOR alternativa 2
//        if (idPosicion > 0) { // Verifica que se haya encontrado una posición válida
//            listaLibros.remove(idPosicion); // Elimina el libro de la posición encontrada
//        } // fin IF eliminación por posición

        // Otra alternativa más compacta usando removeIf y una expresión lambda
        listaLibros.removeIf(x -> x.getId() == id); // Elimina todos los libros cuyo id coincida con el valor recibido
    } // fin método eliminar

    public int totalLibros() { // Método para devolver la cantidad total de libros en la lista
        return listaLibros.size(); // Retorna el tamaño actual de la lista
    } // fin método totalLibros


    //PARTE CLASE 7 INFORMES

    // Método para buscar un libro por su ISBN
    public Libro buscarLibroPorIsbn(String isbn) { // Inicio método buscarLibroPorIsbn
        for (Libro libro : listaLibros) { // Recorre todos los libros de la lista
            if (libro.getIsbn().equals(isbn)) { // Compara el ISBN del libro actual con el ISBN recibido
                return libro; // Retorna el libro encontrado
            } // fin IF búsqueda por ISBN
        } // fin FOR búsqueda por ISBN
        return null; // Si no encuentra coincidencia, retorna null
    } // fin método buscarLibroPorIsbn


    // Método para contar cuántos libros fueron publicados en un año específico
    public int contarLibrosPorAnio(int anio) { // Inicio método contarLibrosPorAnio
        int contador = 0; // Variable para ir acumulando la cantidad de libros encontrados

        for (Libro libro : listaLibros) { // Recorre todos los libros
            if (libro.getFechaPublicacion() == anio) { // Compara el año de publicación del libro con el año recibido
                contador++; // Aumenta el contador en 1
            } // fin IF contar por año
        } // fin FOR contar por año

        return contador; // Retorna la cantidad total encontrada
    } // fin método contarLibrosPorAnio



    // Método para buscar todos los libros de un autor específico
    public List<Libro> buscarLibrosPorAutor(String autor) { // Inicio método buscarLibrosPorAutor
        List<Libro> librosAutor = new ArrayList<>(); // Crea una nueva lista para guardar los libros del autor

        for (Libro libro : listaLibros) { // Recorre todos los libros
            if (libro.getAutor().equalsIgnoreCase(autor)) { // Compara el autor ignorando mayúsculas y minúsculas
                librosAutor.add(libro); // Agrega el libro a la lista de resultados
            } // fin IF búsqueda por autor
        } // fin FOR búsqueda por autor

        return librosAutor; // Retorna la lista de libros encontrados para ese autor
    } // fin método buscarLibrosPorAutor



    // Método para buscar el libro más antiguo
    public Libro buscarLibroMasAntiguo() { // Inicio método buscarLibroMasAntiguo
        if (listaLibros.isEmpty()) { // Verifica si la lista está vacía
            return null; // Si no hay libros, retorna null
        } // fin IF lista vacía

        Libro libroMasAntiguo = listaLibros.get(0); // Toma el primer libro como referencia inicial

        for (Libro libro : listaLibros) { // Recorre todos los libros
            if (libro.getFechaPublicacion() < libroMasAntiguo.getFechaPublicacion()) { // Compara años de publicación
                libroMasAntiguo = libro; // Guarda el libro actual como el más antiguo
            } // fin IF libro más antiguo
        } // fin FOR libro más antiguo

        return libroMasAntiguo; // Retorna el libro más antiguo encontrado
    } // fin método buscarLibroMasAntiguo



    // Método para buscar el libro más nuevo
    public Libro buscarLibroMasNuevo() { // Inicio método buscarLibroMasNuevo
        if (listaLibros.isEmpty()) { // Verifica si la lista está vacía
            return null; // Si no hay libros, retorna null
        } // fin IF lista vacía

        Libro libroMasNuevo = listaLibros.get(0); // Toma el primer libro como referencia inicial

        for (Libro libro : listaLibros) { // Recorre todos los libros
            if (libro.getFechaPublicacion() > libroMasNuevo.getFechaPublicacion()) { // Compara años de publicación
                libroMasNuevo = libro; // Guarda el libro actual como el más nuevo
            } // fin IF libro más nuevo
        } // fin FOR libro más nuevo

        return libroMasNuevo; // Retorna el libro más nuevo encontrado
    } // fin método buscarLibroMasNuevo



    // Método para listar todos los libros ordenados por año de publicación
    public List<Libro> listarLibrosOrdenadosPorAnio() { // Inicio método listarLibrosOrdenadosPorAnio
        List<Libro> librosOrdenados = new ArrayList<>(listaLibros); // Crea una copia de la lista original

        for (int i = 0; i < librosOrdenados.size() - 1; i++) { // Primer ciclo para recorrer posiciones
            for (int j = i + 1; j < librosOrdenados.size(); j++) { // Segundo ciclo para comparar con las posiciones siguientes
                if (librosOrdenados.get(i).getFechaPublicacion() > librosOrdenados.get(j).getFechaPublicacion()) { // Si el año actual es mayor al siguiente
                    Libro temporal = librosOrdenados.get(i); // Guarda temporalmente el libro de la posición i
                    librosOrdenados.set(i, librosOrdenados.get(j)); // Coloca en i el libro de la posición j
                    librosOrdenados.set(j, temporal); // Coloca en j el libro guardado temporalmente
                } // fin IF ordenamiento por año
            } // fin FOR interno ordenamiento
        } // fin FOR externo ordenamiento

        return librosOrdenados; // Retorna la lista ordenada
    } // fin método listarLibrosOrdenadosPorAnio



} // fin clase LibroRepository
