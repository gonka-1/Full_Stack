package com.example.bibliotecaduoc.service; // Paquete donde se encuentra la capa service

import com.example.bibliotecaduoc.exception.IsbnDuplicadoException; // Importa la excepción para ISBN repetido
import com.example.bibliotecaduoc.exception.LibroNoEncontradoException; // Importa la excepción para libro no encontrado
import com.example.bibliotecaduoc.model.Libro; // Importa la clase Libro
import com.example.bibliotecaduoc.repository.LibroRepository; // Importa el repositorio de libros
import org.springframework.beans.factory.annotation.Autowired; // Permite inyectar dependencias automáticamente
import org.springframework.stereotype.Service; // Marca esta clase como servicio de Spring

import java.util.List; // Importa la interfaz List

@Service // Indica que esta clase pertenece a la capa de servicio
public class LibroService { // Inicio de la clase LibroService

    @Autowired // Inyecta automáticamente el repositorio de libros
    private LibroRepository libroRepository; // Variable para usar los métodos del repositorio

    public List<Libro> getLibros() { // Método que obtiene todos los libros
        return libroRepository.obtenerLibros(); // Retorna la lista completa de libros
    } // Fin método getLibros

    public Libro saveLibro(Libro libro) { // Método que guarda un nuevo libro
        Libro libroExistente = libroRepository.buscarLibroPorIsbn(libro.getIsbn()); // Busca si ya existe otro libro con el mismo ISBN

        if (libroExistente != null) { // Verifica si encontró un libro con el mismo ISBN
            throw new IsbnDuplicadoException("Ya existe un libro con ese ISBN."); // Lanza error si el ISBN está repetido
        } // Fin IF ISBN repetido

        return libroRepository.guardar(libro); // Guarda el libro y lo retorna
    } // Fin método saveLibro

    public Libro getLibroId(int id) { // Método que busca un libro por su id
        Libro libro = libroRepository.buscarPorId(id); // Busca el libro en el repositorio

        if (libro == null) { // Verifica si el libro no existe
            throw new LibroNoEncontradoException("Libro con ID " + id + " no encontrado."); // Lanza error si no existe
        } // Fin IF libro no encontrado

        return libro; // Retorna el libro encontrado
    } // Fin método getLibroId

    public Libro updateLibro(Libro libro) { // Método que actualiza un libro existente
        Libro libroActual = libroRepository.buscarPorId(libro.getId()); // Busca el libro actual por su id

        if (libroActual == null) { // Verifica si el libro no existe
            throw new LibroNoEncontradoException("Libro con ID " + libro.getId() + " no encontrado."); // Lanza error si no existe
        } // Fin IF libro no encontrado

        Libro libroConMismoIsbn = libroRepository.buscarLibroPorIsbn(libro.getIsbn()); // Busca si ya existe otro libro con ese ISBN

        if (libroConMismoIsbn != null && libroConMismoIsbn.getId() != libro.getId()) { // Verifica si el ISBN pertenece a otro libro distinto
            throw new IsbnDuplicadoException("Ya existe otro libro con ese ISBN."); // Lanza error por ISBN repetido
        } // Fin IF ISBN duplicado

        return libroRepository.actualizar(libro); // Actualiza el libro en el repositorio y lo retorna
    } // Fin método updateLibro

    public String deleteLibro(int id) { // Método para eliminar un libro por su id
        Libro libro = libroRepository.buscarPorId(id); // Busca el libro antes de eliminarlo

        if (libro == null) { // Verifica si el libro no existe
            throw new LibroNoEncontradoException("Libro con ID " + id + " no encontrado."); // Lanza error si no existe
        } // Fin IF libro no encontrado

        libroRepository.eliminar(id); // Elimina el libro del repositorio
        return "Libro eliminado correctamente."; // Devuelve mensaje de confirmación
    } // Fin método deleteLibro

    public int totalLibrosV2() { // Método que obtiene el total de libros
        return libroRepository.totalLibros(); // Retorna el total de libros desde el repositorio
    } // Fin método totalLibrosV2

    public Libro getLibroPorIsbn(String isbn) { // Método que busca un libro por ISBN
        Libro libro = libroRepository.buscarLibroPorIsbn(isbn); // Busca el libro por ISBN

        if (libro == null) { // Verifica si no encontró el libro
            throw new LibroNoEncontradoException("No se encontró un libro con ese ISBN."); // Lanza error si no existe
        } // Fin IF libro no encontrado

        return libro; // Retorna el libro encontrado
    } // Fin método getLibroPorIsbn

    public int getCantidadLibrosPorAnio(int anio) { // Método que cuenta libros por año
        return libroRepository.contarLibrosPorAnio(anio); // Retorna la cantidad encontrada
    } // Fin método getCantidadLibrosPorAnio

    public List<Libro> getLibrosPorAutor(String autor) { // Método que busca libros por autor
        return libroRepository.buscarLibrosPorAutor(autor); // Retorna la lista encontrada
    } // Fin método getLibrosPorAutor

    public Libro getLibroMasAntiguo() { // Método que obtiene el libro más antiguo
        return libroRepository.buscarLibroMasAntiguo(); // Retorna el libro más antiguo
    } // Fin método getLibroMasAntiguo

    public Libro getLibroMasNuevo() { // Método que obtiene el libro más nuevo
        return libroRepository.buscarLibroMasNuevo(); // Retorna el libro más nuevo
    } // Fin método getLibroMasNuevo

    public List<Libro> getLibrosOrdenadosPorAnio() { // Método que lista libros ordenados por año
        return libroRepository.listarLibrosOrdenadosPorAnio(); // Retorna la lista ordenada
    } // Fin método getLibrosOrdenadosPorAnio

} // Fin de la clase LibroService