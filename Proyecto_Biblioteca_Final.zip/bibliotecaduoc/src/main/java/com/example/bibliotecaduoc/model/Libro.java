package com.example.bibliotecaduoc.model; // Paquete donde se encuentra el modelo Libro

import jakarta.validation.constraints.Max; // Permite validar el valor máximo de un número
import jakarta.validation.constraints.Min; // Permite validar el valor mínimo de un número
import jakarta.validation.constraints.NotBlank; // Permite validar que un texto no venga vacío
import lombok.AllArgsConstructor; // Genera automáticamente un constructor con todos los atributos
import lombok.Data; // Genera getters, setters, toString, equals y hashCode
import lombok.NoArgsConstructor; // Genera automáticamente un constructor vacío

@Data // Genera métodos útiles automáticamente para esta clase
@AllArgsConstructor // Genera un constructor con todos los campos del objeto
@NoArgsConstructor // Genera un constructor sin parámetros
public class Libro { // Inicio de la clase Libro

    private int id; // Guarda el identificador del libro
    @NotBlank(message = "El ISBN es obligatorio") // Valida que el ISBN no venga vacío
    private String isbn; // Guarda el código ISBN del libro
    @NotBlank(message = "El título es obligatorio") // Valida que el título no venga vacío
    private String titulo; // Guarda el título del libro
    @NotBlank(message = "La editorial es obligatoria") // Valida que la editorial no venga vacía
    private String editorial; // Guarda el nombre de la editorial del libro
    @Min(value = 1900, message = "El año de publicación debe ser mayor o igual a 1900") // Valida el año mínimo
    @Max(value = 2100, message = "El año de publicación debe ser menor o igual a 2100") // Valida el año máximo
    private int fechaPublicacion; // Guarda el año de publicación del libro
    @NotBlank(message = "El autor es obligatorio") // Valida que el autor no venga vacío
    private String autor; // Guarda el nombre del autor del libro

} // fin clase Libro