package com.example.bibliotecaduoc.controller; // Paquete donde se encuentra el controller

import com.example.bibliotecaduoc.model.Prestamo; // Importa la clase Prestamo
import com.example.bibliotecaduoc.service.PrestamoService; // Importa la clase PrestamoService
import jakarta.validation.Valid; // Activa las validaciones del modelo Prestamo
import org.springframework.beans.factory.annotation.Autowired; // Permite inyectar dependencias
import org.springframework.http.HttpStatus; // Permite trabajar con códigos HTTP
import org.springframework.http.ResponseEntity; // Permite devolver respuestas HTTP
import org.springframework.web.bind.annotation.*; // Importa las anotaciones REST

import java.util.List; // Importa la interfaz List

@RestController // Indica que esta clase es un controlador REST
@RequestMapping("/api/v1/prestamos") // Ruta base para todos los endpoints de préstamos
public class PrestamoController { // Inicio clase PrestamoController

    @Autowired // Inyecta automáticamente el servicio de préstamos
    private PrestamoService prestamoService; // Variable para usar los métodos del préstamo

    @PostMapping // Este método responde a POST /api/v1/prestamos
    public ResponseEntity<Prestamo> guardarPrestamo(@Valid @RequestBody Prestamo prestamo) { // Método para guardar un préstamo validado
        Prestamo nuevoPrestamo = prestamoService.savePrestamo(prestamo); // Guarda el préstamo recibido
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoPrestamo); // Retorna el préstamo guardado
    } // fin método guardarPrestamo

    @GetMapping("/{id}") // Este método responde a GET /api/v1/prestamos/{id}
    public ResponseEntity<Prestamo> obtenerPrestamo(@PathVariable int id) { // Método para buscar un préstamo por id
        Prestamo prestamo = prestamoService.getPrestamoPorId(id); // Busca el préstamo por su id
        return ResponseEntity.ok(prestamo); // Retorna el préstamo encontrado
    } // fin método obtenerPrestamo

    @GetMapping // Este método responde a GET /api/v1/prestamos
    public ResponseEntity<List<Prestamo>> listarPrestamos() { // Método para listar todos los préstamos
        List<Prestamo> listaPrestamos = prestamoService.getPrestamos(); // Obtiene la lista completa de préstamos
        return ResponseEntity.ok(listaPrestamos); // Retorna 200 OK con la lista de préstamos
    } // fin método listarPrestamos

    @PutMapping("/{id}") // Este método responde a PUT /api/v1/prestamos/{id}
    public ResponseEntity<Prestamo> actualizarPrestamo(@PathVariable int id, @Valid @RequestBody Prestamo prestamo) { // Método para actualizar un préstamo validado
        Prestamo prestamoActualizado = prestamoService.updatePrestamo(id, prestamo); // Actualiza el préstamo
        return ResponseEntity.ok(prestamoActualizado); // Retorna 200 OK con el préstamo actualizado
    } // fin método actualizarPrestamo

    @DeleteMapping("/{id}") // Este método responde a DELETE /api/v1/prestamos/{id}
    public ResponseEntity<Void> eliminarPrestamo(@PathVariable int id) { // Método para eliminar un préstamo
        prestamoService.deletePrestamo(id); // Intenta eliminar el préstamo
        return ResponseEntity.noContent().build(); // Retorna 204 No Content
    } // fin método eliminarPrestamo

} // fin clase PrestamoController