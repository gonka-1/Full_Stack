package com.example.bibliotecaduoc.model; // Paquete donde se encuentra la clase Prestamo

import jakarta.validation.constraints.Min; // Permite validar el valor mínimo de un número
import jakarta.validation.constraints.NotBlank; // Permite validar que un texto no venga vacío
import jakarta.validation.constraints.NotNull; // Permite validar que un objeto no venga null
import lombok.AllArgsConstructor; // Genera constructor con todos los atributos
import lombok.Data; // Genera getters, setters y otros métodos útiles
import lombok.NoArgsConstructor; // Genera constructor vacío

import java.time.LocalDate; // Permite trabajar con fechas

@Data // Genera getters y setters automáticamente
@AllArgsConstructor // Genera constructor con todos los campos
@NoArgsConstructor // Genera constructor vacío
public class Prestamo { // Inicio clase Prestamo

    private int idPrestamo; // Guarda el id del préstamo
    @Min(value = 1, message = "El ID del libro debe ser mayor a 0") // Valida que el id del libro sea mayor a cero
    private int idLibro; // Guarda el id del libro prestado
    @NotBlank(message = "El RUN del solicitante es obligatorio") // Valida que el RUN no venga vacío
    private String runSolicitante; // Guarda el RUN de la persona que solicita el libro
    @NotNull(message = "La fecha de solicitud es obligatoria") // Valida que la fecha de solicitud no venga null
    private LocalDate fechaSolicitud; // Guarda la fecha de solicitud
    private LocalDate fechaEntrega; // Guarda la fecha de entrega
    @Min(value = 1, message = "La cantidad de días debe ser mayor a 0") // Valida que la cantidad de días sea mayor a cero
    private int cantidadDias; // Guarda la cantidad de días del préstamo
    @Min(value = 0, message = "La multa no puede ser negativa") // Valida que la multa no sea negativa
    private int multas; // Guarda el valor de la multa
    private String tituloLibro; // Guarda el nombre del libro asociado al préstamo

} // fin clase Prestamo